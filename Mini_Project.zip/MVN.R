#NAME:MADHU MALI
#PRN:22060641045
#--------------MVN MINI PROJECT-----------
#Multivariate data set is about heart failure clinical record
library(readxl)
d=read.table(file.choose(),header=T)
d
attach(d)
fix(d)
head(d)
str(d)      #nature of variables
y=d$DEATH_EVENT                #if patient died during follow-up period
x1=d$age                       #age of patients(yrs)
x2=d$anaemia                   #Decrease of red blood cells 
x3=d$creatinine_phosphokinase  #level of cpk enzyme in blood(mcg/L)
x4=d$diabetes                  #if patient has diabetes
x5=d$ejection_fraction         #% of blood leaving heart at each contraction
x6=d$high_blood_pressure       #if patient has hypertension
x7=d$platelets                 #platlets in blood(kiloplatlets/mL)
x8=d$serum_creatinine          #level of creatinine in blood(mg/dL)
x9=d$serum_sodium              #level of sodium in blood(mEq/L)
x10=d$sex                      #woman or man
x11=d$smoking                  #if patient smokes
x12=d$time                     #follow-up-period(days)
#There are 299 medical records of heart failure patients with 13 features.DEATH_EVENT is the dependent variable.
#Let X1,X2,...X12 be the 12 regressors and death event (Y) be the response variable.
y=as.factor(d$DEATH_EVENT);y
x1=as.factor(d$age);x1
x2=as.factor(d$anaemia);x2
x3=as.factor(d$creatinine_phosphokinase);x3
x4=as.factor(d$diabetes);x4
x5=as.factor(d$ejection_fraction);x5
x6=as.factor(d$high_blood_pressure);x6
x7=as.factor(d$platelets);x7
x8=as.factor(d$serum_creatinine);x8
x9=as.factor(d$serum_sodium);x9
x10=as.factor(d$sex);x10
x11=as.factor(d$smoking);x11
x12=as.factor(d$time);x12
a=data.frame(y,x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,x12)
m=as.matrix(d)
m
IQR(d$age)
summary(d)
library(pastecs)
stat.desc(d)
tab=table(d$age)  #no. of occurrences for each unique value
sort(tab,decreasing = TRUE)  #Sort highest to lowest
n=cbind(y,x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,x12)
pairs(n)
cov(n)
c=cor(n)
c
library(corrplot)
corrplot(c,type="full",col = "yellow",cl.pos='n',bg="blue",title = "Correlation plot of heart failure clinical record",tl.col="orange",cl.lenghth=5,rect.col="black",pch = 10)
#There is a negative correlation between the time and DEATH_EVENT & positive correlation between age & DEATH_EVENT & serum_creatinine and DEATH_EVENT.
#Density plot
plot(density(0,bw=1,xlab=12,from=-1.2,to=1.2,width=2,kernel = 'gaussian'),type="l",ylim=c(0,1),xlab="variables")
#Checking for duplicates
duplicated(d)
#Checking for Nulls
is.null(d)
#Fitting of logistic regression model
#f=glm(y~x1+x2+x3+x4+x5+x6+x7+x8+x9+x10+x11+x12,family=binomial)
#f
#summary(f)     
#DECISION TREES
library(rpart)
library(rpart.plot)
d_model=rpart(DEATH_EVENT~.,d,method='class')
predicted_val=predict(d_model,d,type='class')
prob=predict(d_model,d,type='prob')
rpart.plot(d_model)
boxplot(d,xlab="dependent variable",ylab="independent variable")
library(ggplot2)
df=d
ggplot(df,aes(x=anaemia,fill=DEATH_EVENT))+
  geom_bar(stat="count",position="stack",show.legend=FALSE)+
  scale_x_discrete(labels=c("0(FALSE)","1(TRUE)"))+
  labs(x="Anaemia")+
  theme_minimal(base_size=11)+
  geom_label(stat="count",aes(label=..count..),position=position_stack(vjust=0.5),size=5) 
#Seprating the data into train and test part,this resulted in 75% train part out of total data(constructed by straified sampling) 
data=d
library(sampling)
set.seed(5)
idx=sampling:::strata(d,stratanames=c('DEATH_EVENT'),size=c(3/4*96,3/4*203),method='srswor')
train=d[idx$ID_unit,]
test=d[-idx$ID_unit,]
#Fit the logistic regression model to training data
l=glm(DEATH_EVENT~., family=binomial,data=train)
l
summary(l)   #AIC=169.06
#From the O/P we observe that,estimates of parameters involved in this model: Intercept:2.414e+01, S1=5.887e-02,S2=4.765e-01,S3=...,s12=-2.514e-02
#Standard errors pf regression coeff. are given in 2nd column of coeff. table.
#The logistic regression model may be written as,
#pi(x)=e^( 2.414e+01 +5.887e-02x1+4.765e-01x2+2.542e-04x3+3.236e-01x4-8.585e-02x5+ 1.396e-01x6 -3.864e-06x7+8.774e-01x8-1.712e-01x9-7.796e-01x10+7.599e-01x11-2.514e-02x12)/(1+e^(2.414e+01 +5.887e-02x1+4.765e-01x2+2.542e-04x3+3.236e-01x4-8.585e-02x5+ 1.396e-01x6 -3.864e-06x7+8.774e-01x8-1.712e-01x9-7.796e-01x10+7.599e-01x11-2.514e-02x12))
#Beta1=5.887e-02 implies that e^(beta1)=1.0606455. It can be interpreted as , for every unit increase in age the chance of death_event increase by 06.06%.

#Testing significance of regression at 5% los-
cat("H01=B1=B2=B3=B4=B5=B6=B7=B8=B9=B10=B11=B12=0\n Vs\n H11: B1=B2...=B12!=0\n")
#Null Deviance=281.32     Residual Deviance=143.06
#G=Hessian matrix follows chisq with df 1
#G=Null Deviance- Residual Deviance=138.26
#Chisq(12,0.05)=21.026
#Since, G exceeds, H01 is rejected at 5% los.Hence, atleast 1 regression coeff. is significant.
#From pvalue in last column we observe that age,ejection_fraction,serum_creatinine,serum_sodium,time are significant. 
par(mfrow=c(2,2))
plot(l)
#Interpretation from the plots:
#Normal Q-Q plot:Flat extremes indicates that observations are from a distribution having tails thinner that normal distribution.This shows linear trend
#Predicting on test set & printing classification matrix to find model performance
p=predict(l,test,type="response")
Predict=rep(0,dim(test)[1])
Actual=test$DEATH_EVENT
table(Predict,Actual)
#After removing the non-significant variables and fitting the model again
lr=glm(DEATH_EVENT~age+ejection_fraction+serum_creatinine+serum_sodium+time,family=binomial,data=train)
summary(lr)
#The accuracy of our logistic model is 76 %
#Improving the model by standardizing variables
f=subset(data,select=c(age,ejection_fraction,serum_creatinine,serum_sodium,time))
scale=scale(f)
#Adding label column (DEATH_EVENT) back to scaled data
DEATH_EVENT=data$DEATH_EVENT
ndf=data.frame(scale,DEATH_EVENT)
head(ndf)
#creating test and train set again
idx1=sample(1:nrow(ndf),3/4*nrow(ndf))
train1=ndf[idx1,]
test1=ndf[-idx1,]
#Fitting logistic regression model with the standardized data
n_l=glm(DEATH_EVENT~age+ejection_fraction+serum_creatinine+serum_sodium+time,family=binomial,data=train1)
summary(n_l)
predict(n_l,test1,type="response")
Predict1=rep(0,dim(test1)[1])
Actual1=test1$DEATH_EVENT
table(Predict1,Actual1)
#THE ACCURACY OF MODEL ID 78%
#THE CLASSIFICATION TREE MODEL
#we are using classification tree model as we have quantitative response in model.
#Appling Classifcation tree to train part
library(tree)
tree.class=tree(factor(DEATH_EVENT)~.,train)
summary(tree.class)
plot(tree.class)          #plotting the tree
text(tree.class,pretty=0)
tree.predict=predict(tree.class,test,type='class')
table(tree.predict,test$DEATH_EVENT)
mean(tree.predict==test$DEATH_EVENT)
#FITTING LINEAR DISCRIMINANT ANALYSIS MODEL to training model
library(MASS)
library(ISLR)
lda=lda(factor(DEATH_EVENT)~.,data=train)
#refitting by significant variables
lda=lda(factor(DEATH_EVENT)~age+ejection_fraction+serum_creatinine+serum_sodium+time, data=train)
lda
pred=predict(lda,test)
mean(pred$class==test$DEATH_EVENT)
#Accuracy of model is 78.66667%
#Therefore,choosing Linear Discriminant Analysis as final model.
#CONCLUSION: It can be concluded that growing age,having serum creatinine>1.5, hypertension,higher level of anemia & low value of ejection fraction are key factors contibution towards increased mortality rate among heart failure patients.






